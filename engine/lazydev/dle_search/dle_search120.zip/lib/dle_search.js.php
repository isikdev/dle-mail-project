<?php
@error_reporting(E_ALL ^ E_WARNING ^ E_DEPRECATED ^ E_NOTICE);
@ini_set('error_reporting', E_ALL ^ E_WARNING ^ E_DEPRECATED ^ E_NOTICE);

header('Content-Type: application/x-javascript');
use LazyDev\Search\Data;
include_once realpath(__DIR__ . '/..') . '/class/Data.php';
Data::load();
$modConfig = Data::receive('config');

$ajaxOn = intval($modConfig['ajax_on']);
$maximumNews = intval($modConfig['maximum_news_ajax']);
$ajaxCategory = intval($modConfig['ajax_category']);
$ajaxTags = intval($modConfig['ajax_tags']);
$ajaxXfield = intval($modConfig['ajax_xfield']);
$url = intval($modConfig['url_on']);

echo <<<HTML
let dleSearchConfig = {
    ajax: {$ajaxOn},
    maximunNews: {$maximumNews},
    ajaxCategory: {$ajaxCategory},
    ajaxTags: {$ajaxTags},
    ajaxXfield: {$ajaxXfield},
    url: {$url},
    page: window.location.pathname
};
HTML;

?>
