<?php
/**
* Дизайн админ панель
*
* @link https://lazydev.pro/
* @author LazyDev <email@lazydev.pro>
**/

if (!defined('DATALIFEENGINE') || !defined('LOGGED_IN')) {
	header('HTTP/1.1 403 Forbidden');
	header('Location: ../../');
	die('Hacking attempt!');
}

$jsAdminScript = implode($jsAdminScript);
$additionalJsAdminScript = implode($additionalJsAdminScript);
echo '
                        <div class="panel panel-default" style="display: block;position: absolute;left: 0;bottom: 0;width: 97.5%;margin-left: 20px;height: 55px;">
                            <div class="panel-content">
                                <div class="panel-body">
                                    &copy; <a href="https://lazydev.pro/" target="_blank">LazyDev</a> ' . date('Y', time()) . ' All rights reserved.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="' . $config['http_home_url'] . 'engine/lazydev/' . $modLName . '/admin/template/assets/core.js"></script>
        <script>let coreAdmin = new Admin("' . $modLName . '"); ' . $jsAdminScript . '</script>
        <script>
let selectTag = tail.select(".selectTag", {
    search: true,
    multiSelectAll: true,
    classNames: "default white",
    multiContainer: true,
    multiShowCount: false,
    locale: "ru"
});
        </script>
        ' . $additionalJsAdminScript . '
    </body>
</html>';

?>