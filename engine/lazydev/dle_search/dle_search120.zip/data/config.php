<?php

//DLE Search by LazyDev

return array (
  'rows' => 
  array (
    0 => 'p.title',
    1 => 'xf_okpd-tnved',
  ),
  'concat' => '',
  'sort_by_pos' => 1,
  'sort_by_pos_xf' => '-',
  'keyboard' => 1,
  'between_space' => 1,
  'replace_char' => ',.[]/":\\\'1234567890',
  'substitution' => 1,
  'cache' => 1,
  'statistics' => 1,
  'clear_statistics' => 0,
  'exclude_categories' => 
  array (
    0 => '5',
    1 => 8,
  ),
  'minimum_char' => 3,
  'maximum_char' => 60,
  'sort_field' => 'p.editdate',
  'order' => 'asc',
  'maximum_news_ajax' => 10,
  'maximum_news_full' => 32,
);
