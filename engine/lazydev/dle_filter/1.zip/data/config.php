<?php

//DLE Filter by LazyDev

return array (
  'cache_filter' => 1,
  'clear_statistics' => 0,
  'exclude_categories' => 
  array (
    0 => 8,
  ),
  'search_cat_all' => 1,
  'news_number' => 48,
  'max_news' => 0,
  'sort_field' => 'editdate',
  'order' => 'desc',
  'filter_url' => 'f',
  'ion_slider' => 1,
  'js_select' => 1,
  'ajax_nav' => 1,
  'index_filter' => 'index',
  'index_second' => 'noindex',
  'code_filter' => 'default',
  'redirect_filter' => 1,
  'link' => 
  array (
  ),
  'exchange' => 
  array (
  ),
);
