<?php
global $db;

$this->priority = '0.8';
$xml = '';
$db->query("SELECT page_url, dateEdit, date FROM " . PREFIX . "_dle_filter_pages WHERE sitemap");
while ($row = $db->get_row()) {
    $url = $this->home . $row['page_url'] . '/';
    $date = $row['editDate'] ? $row['editDate'] : ($row['date'] ?: date('Y-m-d', time()));
    $date = date('Y-m-d', strtotime($date));
    $xml .= $this->get_xml($url, $date);
}

$map .= $xml;