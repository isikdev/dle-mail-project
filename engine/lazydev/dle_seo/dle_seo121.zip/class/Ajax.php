<?php
/**
 * Класс AJAX обработки админ панели
 *
 * @link https://lazydev.pro/
 * @author LazyDev <email@lazydev.pro>
 **/

namespace LazyDev\Seo;

use ParseFilter;
use DLEPlugins;

include_once (DLEPlugins::Check(ENGINE_DIR . '/classes/parse.class.php'));

class Ajax
{
    /**
     * Определяем AJAX действие
     *
     * @param    string    $action
     *
     **/
    static function ajaxAction($action)
    {
        switch ($action) {
            case 'saveOptions':
                self::saveOptions();
                break;
            case 'addSeo':
                self::addSeo();
                break;
            case 'addRule':
                self::addRule();
                break;
            case 'addRuleCat':
                self::addRuleCat();
                break;
            case 'deleteRule':
                self::deleteRule();
                break;
            case 'deleteSeo':
                self::deleteSeo();
                break;
            case 'deleteRuleCat':
                self::deleteRuleCat();
                break;
            case 'clearCache':
                self::clearCache();
                break;
        }
    }

    /**
     * Удаление записи
     *
     */
    static function deleteSeo()
    {
        global $dleSeoLang, $db;

        $id = intval($_POST['id']);
        $db->query("DELETE FROM " . PREFIX . "_dle_seo WHERE id='{$id}'");

        $row = $db->super_query("SELECT name  FROM " . PREFIX . "_dle_seo_files WHERE seoId='{$id}' AND type='0'");
        $listimages = explode('|||', $row['name']);

        foreach ($listimages as $dataimages) {
            $url_image = explode('/', $dataimages);

            if (count($url_image) == 2) {
                $folder_prefix = $url_image[0] . '/';
                $dataimages = $url_image[1];
            } else {
                $folder_prefix = '';
                $dataimages = $url_image[0];
            }

            @unlink(ROOT_DIR . '/uploads/dle_seo/' . $folder_prefix . $dataimages);
            @unlink(ROOT_DIR . '/uploads/dle_seo/' . $folder_prefix . 'thumbs/' . $dataimages);
            @unlink(ROOT_DIR . '/uploads/dle_seo/' . $folder_prefix . 'medium/' . $dataimages);
        }
        $db->query("DELETE FROM " . PREFIX . "_dle_seo_files WHERE seoId='{$id}' AND type='0'");

        $db->query("SELECT id, onserver FROM " . PREFIX . "_dle_seo_files WHERE seoId='{$id}' AND type='1'");
        while ($row = $db->get_row()) {
            $url = explode('/', $row['onserver']);

            $folder_prefix = '';
            $file = $url[0];
            if (count($url) == 2) {
                $folder_prefix = $url[0] . '/';
                $file = $url[1];
            }

            $file = totranslit($file, false);

            if (trim($file) == '.htaccess') {
                continue;
            }

            @unlink(ROOT_DIR . '/uploads/dle_seo/' . $folder_prefix . $file);
        }
        $db->query("DELETE FROM " . PREFIX . "_dle_seo_files WHERE seoId='{$id}' AND type='1'");

        echo Helper::json(['text' => $dleSeoLang['admin']['ajax']['delete_seo']]);
    }

    /**
     * Удаление правила новостей
     *
     */
    static function deleteRule()
    {
        global $dleSeoLang, $db;

        $id = intval($_POST['id']);
        $newsRule = Data::receive('news');

        unset($newsRule[$id]);
        $handler = fopen(ENGINE_DIR . '/lazydev/' . Helper::$modName . '/data/news.php', 'w');
        fwrite($handler, "<?php\n\n//DLE Seo by LazyDev\n\nreturn ");
        fwrite($handler, var_export($newsRule, true));
        fwrite($handler, ";\n");
        fclose($handler);

        $db->query("DELETE FROM " . PREFIX . "_dle_seo_news WHERE id='{$id}'");

        echo Helper::json(['text' => $dleSeoLang['admin']['ajax']['delete_rule']]);
    }

    /**
     * Удаление правила категорий
     *
     */
    static function deleteRuleCat()
    {
        global $dleSeoLang, $db;

        $id = intval($_POST['id']);
        $newsRule = Data::receive('cat');

        unset($newsRule[$id]);
        $handler = fopen(ENGINE_DIR . '/lazydev/' . Helper::$modName . '/data/cats.php', 'w');
        fwrite($handler, "<?php\n\n//DLE Seo by LazyDev\n\nreturn ");
        fwrite($handler, var_export($newsRule, true));
        fwrite($handler, ";\n");
        fclose($handler);

        $db->query("DELETE FROM " . PREFIX . "_dle_seo_cats WHERE id='{$id}'");

        $id = 'cat_' . $id;
        $row = $db->super_query("SELECT name  FROM " . PREFIX . "_dle_seo_files WHERE seoId='{$id}' AND type='0'");
        $listimages = explode('|||', $row['name']);

        foreach ($listimages as $dataimages) {
            $url_image = explode('/', $dataimages);

            if (count($url_image) == 2) {
                $folder_prefix = $url_image[0] . '/';
                $dataimages = $url_image[1];
            } else {
                $folder_prefix = '';
                $dataimages = $url_image[0];
            }

            @unlink(ROOT_DIR . '/uploads/dle_seo/' . $folder_prefix . $dataimages);
            @unlink(ROOT_DIR . '/uploads/dle_seo/' . $folder_prefix . 'thumbs/' . $dataimages);
            @unlink(ROOT_DIR . '/uploads/dle_seo/' . $folder_prefix . 'medium/' . $dataimages);
        }
        $db->query("DELETE FROM " . PREFIX . "_dle_seo_files WHERE seoId='{$id}' AND type='0'");

        $db->query("SELECT id, onserver FROM " . PREFIX . "_dle_seo_files WHERE seoId='{$id}' AND type='1'");
        while ($row = $db->get_row()) {
            $url = explode('/', $row['onserver']);

            $folder_prefix = '';
            $file = $url[0];
            if (count($url) == 2) {
                $folder_prefix = $url[0] . '/';
                $file = $url[1];
            }

            $file = totranslit($file, false);

            if (trim($file) == '.htaccess') {
                continue;
            }

            @unlink(ROOT_DIR . '/uploads/dle_seo/' . $folder_prefix . $file);
        }
        $db->query("DELETE FROM " . PREFIX . "_dle_seo_files WHERE seoId='{$id}' AND type='1'");


        echo Helper::json(['text' => $dleSeoLang['admin']['ajax']['delete_rule']]);
    }
    /**
     * Добавление записи
     */
    static function addSeo()
    {
        global $dleSeoLang, $member_id, $config, $db;

        @header('X-XSS-Protection: 0;');

        $parse = new ParseFilter();
        $idSeo = intval($_POST['idSeo']);
        $type = intval($_POST['type']);

        if (empty($_POST['valSeo'])) {
            echo Helper::json(['text' => $dleSeoLang['admin']['ajax']['not_seo'], 'error' => 'true']);
            exit;
        }

        $arrayVal = [];
        foreach ($_POST['valSeo'] as $nameVal) {
            $arrayVal[] = $db->safesql(trim(strip_tags($nameVal)));
        }
        $arrayVal = array_unique($arrayVal);
        $valStr = implode(',', $arrayVal);

        $xfName = $_POST['xf_name'] ? $parse->process(trim(strip_tags($_POST['xf_name']))) : '';

        $seo_title = $db->safesql($parse->process(trim(strip_tags($_POST['seo_title']))));

        $description = $parse->process($_POST['short_story']);
        $description = $db->safesql($parse->BB_Parse($description, (bool)$config['allow_admin_wysiwyg']));


        $fastquotes = ["\x22", "\x60", "\t", "\n", "\r", '"', '\r', '\n', "$", "\\"];

        $_meta['meta_title'] = trim(htmlspecialchars(strip_tags(stripslashes($_POST['meta_title'])), ENT_COMPAT, $config['charset']));
        $_meta['meta_title'] = preg_replace('/\s+/u', ' ', str_replace($fastquotes, '', $_meta['meta_title']));
        $_meta['meta_descr'] = trim(strip_tags(stripslashes($_POST['meta_descr'])));
        $_meta['meta_key'] = trim(strip_tags(stripslashes($_POST['meta_key'])));
        $_meta['meta_speedbar'] = trim(strip_tags(stripslashes($_POST['meta_speedbar'])));

        $_og['title'] = trim(htmlspecialchars(strip_tags(stripslashes($_POST['og_title'])), ENT_COMPAT, $config['charset']));
        $_og['title'] = preg_replace('/\s+/u', ' ', str_replace($fastquotes, '', $_og['title']));
        $_og['description'] = trim(strip_tags(stripslashes($_POST['og_descr'])));
        $_og['image'] = $db->safesql($_POST['og_photo']);

        $meta = Helper::stringData($_meta);
        $og = Helper::stringData($_og);

        $check = $db->super_query("SELECT id FROM " . PREFIX . "_dle_seo WHERE id='{$idSeo}'")['id'];
        if ($check) {
            $db->query("UPDATE " . PREFIX . "_dle_seo SET `type`='{$type}', `meta`='{$meta}', `og`='{$og}', `seoTitle`='{$seo_title}', `seoText`='{$description}', `val`='{$valStr}', `xfName`='{$xfName}' WHERE id='{$idSeo}'");
            $db->query("DELETE FROM " . PREFIX . "_dle_seo_value WHERE seoId='{$idSeo}'");
            foreach ($arrayVal as $Val) {
                $db->query("INSERT INTO " . PREFIX . "_dle_seo_value (`seoId`, `type`, `value`, `xfieldName`) VALUES ('{$idSeo}', '{$type}', '{$Val}', '{$xfName}')");
            }
            $db->query("UPDATE " . PREFIX . "_dle_seo_files SET seoId='{$idSeo}' WHERE author='{$member_id['name']}' AND seoId='0'");
            echo Helper::json(['type' => 'edit', 'id' => $idSeo, 'add' => $type]);
        } else {
            $db->query("INSERT INTO " . PREFIX . "_dle_seo (`type`, `meta`, `og`, `seoTitle`, `seoText`, `val`, `xfName`) VALUES ('{$type}', '{$meta}', '{$og}', '{$seo_title}', '{$description}', '{$valStr}', '{$xfName}')");
            $id = $db->insert_id();
            foreach ($arrayVal as $Val) {
                $db->query("INSERT INTO " . PREFIX . "_dle_seo_value (`seoId`, `type`, `value`, `xfieldName`) VALUES ('{$id}', '{$type}', '{$Val}', '{$xfName}')");
            }
            $db->query("UPDATE " . PREFIX . "_dle_seo_files SET seoId='{$id}' WHERE author='{$member_id['name']}' AND seoId='0'");
            echo Helper::json(['type' => 'add', 'id' => $id, 'add' => $type]);
        }
    }

    /**
     * Сохранение правил для новостей
     *
     */
    static function addRule()
    {
        global $config, $db;

        @header('X-XSS-Protection: 0;');

        $parse = new ParseFilter();
        $fastquotes = ["\x22", "\x60", "\t", "\n", "\r", '"', '\r', '\n', "$", "\\"];

        $newsRule = Data::receive('news');
        $indexEdit = intval($_POST['id']);

        $catArray = [];
        foreach ($_POST['cat'] as $cat) {
            if (is_numeric($cat)) {
                $cat = intval($cat);
                $catArray[$cat] = $cat;
            } elseif ($cat == 'all') {
                unset($catArray);
                $catArray = ['all'];
                break;
            } else {
                continue;
            }
        }
        $cats = $db->safesql(implode(',', $catArray));

        $change = intval($_POST['change']);

        $_meta['title'] = trim(htmlspecialchars(strip_tags(stripslashes($_POST['meta_title'])), ENT_COMPAT, $config['charset']));
        $_meta['title'] = preg_replace('/\s+/u', ' ', str_replace($fastquotes, '', $_meta['title']));
        $_meta['descr'] = trim(strip_tags(stripslashes($_POST['meta_descr'])));
        $_meta['speedbar'] = trim(strip_tags(stripslashes($_POST['meta_speedbar'])));

        $_og['title'] = trim(htmlspecialchars(strip_tags(stripslashes($_POST['meta_og_title'])), ENT_COMPAT, $config['charset']));
        $_og['title'] = preg_replace('/\s+/u', ' ', str_replace($fastquotes, '', $_og['title']));
        $_og['descr'] = trim(strip_tags(stripslashes($_POST['meta_og_descr'])));
        $_og['image'] = $parse->process(trim(strip_tags($_POST['meta_og_image'])));
        $_og['default'] = $parse->process(trim(strip_tags($_POST['default_image'])));

        $meta = Helper::stringData($_meta);
        $og = Helper::stringData($_og);

        if ($indexEdit > 0) {
            $id = $indexEdit;
            $db->query("UPDATE " . PREFIX . "_dle_seo_news SET `cats`='{$cats}', `meta`='{$meta}', `og`='{$og}', `replacement`='{$change}' WHERE id='{$indexEdit}'");
        } else {
            $db->query("INSERT INTO " . PREFIX . "_dle_seo_news (`cats`, `meta`, `og`, `replacement`) VALUES ('{$cats}', '{$meta}', '{$og}', '{$change}')");
            $id = $db->insert_id();
        }

        $newsRule[$id] = $catArray;
        $handler = fopen(ENGINE_DIR . '/lazydev/' . Helper::$modName . '/data/news.php', 'w');
        fwrite($handler, "<?php\n\n//DLE Seo by LazyDev\n\nreturn ");
        fwrite($handler, var_export($newsRule, true));
        fwrite($handler, ";\n");
        fclose($handler);

        echo Helper::json(['type' => 'rule', 'id' => $id, 'index' => $indexEdit, 'from' => 'news']);
    }

    /**
     * Сохранение правил для категорий
     *
     */
    static function addRuleCat()
    {
        global $config, $db, $member_id;

        @header('X-XSS-Protection: 0;');

        $parse = new ParseFilter();
        $fastquotes = ["\x22", "\x60", "\t", "\n", "\r", '"', '\r', '\n', "$", "\\"];

        $newsRule = Data::receive('cat');
        $indexEdit = intval($_POST['id']);

        $catArray = [];
        foreach ($_POST['cat'] as $cat) {
            if (is_numeric($cat)) {
                $cat = intval($cat);
                $catArray[$cat] = $cat;
            } elseif ($cat == 'all') {
                unset($catArray);
                $catArray = ['all'];
                break;
            } else {
                continue;
            }
        }
        $cats = $db->safesql(implode(',', $catArray));

        $change = intval($_POST['change']);

        $_meta['title'] = trim(htmlspecialchars(strip_tags(stripslashes($_POST['meta_title'])), ENT_COMPAT, $config['charset']));
        $_meta['title'] = preg_replace('/\s+/u', ' ', str_replace($fastquotes, '', $_meta['title']));
        $_meta['descr'] = trim(strip_tags(stripslashes($_POST['meta_descr'])));
        $_meta['speedbar'] = trim(strip_tags(stripslashes($_POST['meta_speedbar'])));

        $_og['title'] = trim(htmlspecialchars(strip_tags(stripslashes($_POST['meta_og_title'])), ENT_COMPAT, $config['charset']));
        $_og['title'] = preg_replace('/\s+/u', ' ', str_replace($fastquotes, '', $_og['title']));
        $_og['descr'] = trim(strip_tags(stripslashes($_POST['meta_og_descr'])));
        $_og['image'] = $parse->process(trim(strip_tags($_POST['default_image'])));

        $meta = Helper::stringData($_meta);
        $og = Helper::stringData($_og);

        $title = $db->safesql($parse->process(trim(strip_tags($_POST['h1_title']))));
        $description = $parse->process($_POST['short_story']);
        $description = $parse->BB_Parse($description, (bool)$config['allow_admin_wysiwyg']);
        $description = $db->safesql($description);

        if ($indexEdit > 0) {
            $id = $indexEdit;
            $db->query("UPDATE " . PREFIX . "_dle_seo_cats SET `cats`='{$cats}', `meta`='{$meta}', `og`='{$og}', `replacement`='{$change}', `title`='{$title}', `text`='{$description}' WHERE id='{$indexEdit}'");
        } else {
            $db->query("INSERT INTO " . PREFIX . "_dle_seo_cats (`cats`, `meta`, `og`, `replacement`, `title`, `text`) VALUES ('{$cats}', '{$meta}', '{$og}', '{$change}', '{$title}', '{$description}')");
            $id = $db->insert_id();
        }

        $newsRule[$id] = $catArray;
        $handler = fopen(ENGINE_DIR . '/lazydev/' . Helper::$modName . '/data/cats.php', 'w');
        fwrite($handler, "<?php\n\n//DLE Seo by LazyDev\n\nreturn ");
        fwrite($handler, var_export($newsRule, true));
        fwrite($handler, ";\n");
        fclose($handler);

        $db->query("UPDATE " . PREFIX . "_dle_seo_files SET seoId='cat_{$id}' WHERE author='{$member_id['name']}' AND seoId='cat_-1'");
        echo Helper::json(['type' => 'rule', 'id' => $id, 'index' => $indexEdit, 'from' => 'cat']);
    }

    /**
     * Сохраняем настройки
     *
     **/
    static function saveOptions()
    {
        $arrayConfig = Helper::unserializeJs($_POST['data']);
        $handler = fopen(ENGINE_DIR . '/lazydev/' . Helper::$modName . '/data/config.php', 'w');
        fwrite($handler, "<?php\n\n//DLE Seo by LazyDev\n\nreturn ");
        fwrite($handler, var_export($arrayConfig, true));
        fwrite($handler, ";\n");
        fclose($handler);

        echo Helper::json(['text' => Data::get(['admin', 'ajax', 'options_save'], 'lang')]);
    }

    /**
     * Очищаем кэш
     *
     **/
    static function clearCache()
    {
        Cache::clear();
        echo Helper::json(['text' => Data::get(['admin', 'ajax', 'clear_cache'], 'lang')]);
    }
}
