<?php
/**
* Вспомогательный класс с набором функций
*
* @link https://lazydev.pro/
* @author LazyDev <email@lazydev.pro>
**/

namespace LazyDev\Seo;

class Helper
{
    static $modName = 'dle_seo';

    /**
    * Разбор serialize строки
    *
    * @param    string   $data_form
    * @return   array
    **/
    static function unserializeJs($data_form)
    {
        $new_array = [];
        if ($data_form) {
            parse_str($data_form, $array_post);

            foreach ($array_post as $index => $item) {
                if (is_array($item)) {
                    foreach ($item as $key => $value) {
                        if (is_array($value)) {
                            foreach ($value as $k => $v) {
                                if ($v != '' && $v != '-') {
                                    $new_array[$index][$key][] = self::typeValue($v);
                                }
                            }
                        } elseif ($value != '' && $value != '-') {
                            $new_array[$index][$key] = self::typeValue($value);
                        }
                    }
                } elseif ($item != '' && $item != '-') {
                    $new_array[$index] = self::typeValue($item);
                }
            }
        }
        
        return $new_array;
    }

    /**
    * Типизация данных
    *
    * @param    mixed   $v
    * @return   float|int|string
    **/
    static function typeValue($v)
    {
        if (is_numeric($v)) {
            if (is_float($v)) {
                $v = floatval($v);
            } else {
                $v = intval($v);
            }
        } else {
            $v = strip_tags(stripslashes($v));
        }
        
        return $v;
    }
    
    /**
    * Json для js
    *
    * @param    array   $v
    * @return   string
    **/
    static function json($v)
    {
        return json_encode($v, JSON_UNESCAPED_UNICODE);
    }
    
    /**
    * Получить данные с массива по массиву ключей
    *
    * @param    array   $a
    * @param    array   $k
    * @param    int     $c
    * @return   string
    **/
    static public function multiArray($a, $k, $c)
    {
        return ($c > 1) ? self::multiArray($a[$k[count($k) - $c]], $k, ($c - 1)) : $a[$k[(count($k) - 1)]];
    }

    /**
     * Очистить строку от последнего слэша
     *
     * @param    string   $v
     * @return   string
     **/
    static function cleanSlash($v)
    {
        if (substr($v, -1, 1) == '/') {
            $v = substr($v, 0, -1);
        }

        return $v;
    }

    /**
     * too old
     *
     * @param    string   $val
     * @return   string
     **/
    static function decodeString($val)
    {
        return $val;
    }

    /**
     * Тип доп полей
     *
     * @param    array   $arr
     * @return   string
     **/
    static function stringData($arr)
    {
        global $db;
        $arrTemp = [];
        foreach ($arr as $xfielddataname => $xfielddatavalue) {
            if ($xfielddataname == '' || $xfielddatavalue == '') {
                continue;
            }

            $xfielddataname = str_replace(['|', '\r\n'], ['&#124;', '__NEWL__'], $xfielddataname);
            $xfielddatavalue = str_replace(['|', '\r\n'], ['&#124;', '__NEWL__'], $xfielddatavalue);
            $arrTemp[] = $xfielddataname . '|' . $xfielddatavalue;
        }

        $str = count($arrTemp) ? $db->safesql(implode('||', $arrTemp)) : '';
        return $str;
    }

    /**
     * Тип доп полей
     *
     * @param    mixed   $data
     * @return   string
     **/
    static function checkPopupData($data)
    {
        return $data ?: '<i class="fa fa-close" style="color: red;"></i>';
    }

    /**
     * Обнуление пути
     *
     * @param    string   $url
     * @return   string
     **/
    static function resetUrl($url)
    {
        $url = (string)$url;
        $value = str_replace(["http://", "https://", "www."], '', $url);
        $value = explode('/', $value);
        $value = reset($value);
        return $value;
    }

    /**
     * Очистка пути
     *
     * @param    string   $var
     * @return   string
     **/
    static function cleanDir($var)
    {
        $var = (string)$var;
        $var = str_ireplace('.php', '', $var);
        $var = str_ireplace('.php', '.ppp', $var);
        $var = trim(strip_tags($var));
        $var = str_replace("\\", '/', $var);
        $var = preg_replace("/[^a-z0-9\/\_\-]+/mi", '', $var);
        return $var;
    }
}
