<?php
/**
* Дизайн админ панель
*
* @link https://lazydev.pro/
* @author LazyDev <email@lazydev.pro>
**/

if (!defined('DATALIFEENGINE') || !defined('LOGGED_IN')) {
	header('HTTP/1.1 403 Forbidden');
	header('Location: ../../');
	die('Hacking attempt!');
}

use LazyDev\Seo\Data;

$styleNight = $night = '';
if (date('G') > 7 && date('G') < 20) {
} else {
    $night = 'dle_theme_dark';
    $styleNight = <<<HTML
<style>
.navbar-inverse {
    background: #2e3131!important;
}
.chosen-container-multi .chosen-choices li.search-field input[type="text"] {
    color: #fff;
}
.panel-body + .panel-body, .panel-body + .table, .panel-body + .table-responsive, .panel-body.has-top-border {
    border-top: 1px solid rgba(255,255,255,0.2)!important;;
}
.chosen-container-single .chosen-single span {
    color: #f2f1ef!important;
}
.dle_theme_dark .panel, .dle_theme_dark .modal-content {
    color: #ffffff!important;
    background-color: #2e3131!important;
}
.chosen-container-single .chosen-search {
    background: #403c3c!important;
}
.chosen-container-single .chosen-search input[type=text] {
    color: #000!important;
}
body.dle_theme_dark {
    background-color: #545454!important;
}
.section_icon {
    background: transparent!important;
    box-shadow: none!important;
    -webkit-box-shadow: none!important;
}
.gray-theme.fr-box.fr-basic .fr-wrapper {
    background: #2e3131!important;
}
label.status {
    background: #2e3131;
}
</style>

HTML;

}

echo <<<HTML
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{$dleSeoLang['admin']['title']}</title>
        <link href="engine/skins/fonts/fontawesome/styles.min.css" rel="stylesheet" type="text/css">
        <link href="engine/skins/stylesheets/application.css" rel="stylesheet" type="text/css">
        <link href="{$config['http_home_url']}engine/lazydev/{$modLName}/admin/template/assets/style.css" rel="stylesheet" type="text/css">
        <script src="engine/skins/javascripts/application.js"></script>
        <script>
            let dle_act_lang = [{$dleSeoLang['admin']['other']['jslang']}];
            let cal_language = {
                en: {
                    months: [{$dleSeoLang['admin']['other']['jsmonth']}],
                    dayOfWeekShort: [{$dleSeoLang['admin']['other']['jsday']}]
                }
            };
            let filedefaulttext = '{$dleSeoLang['admin']['other']['jsnotgot']}';
            let filebtntext = '{$dleSeoLang['admin']['other']['jschoose']}';
            let dle_login_hash = '{$dle_login_hash}';
        </script>
        {$styleNight}
    </head>
    <body class="{$night}">
        <div id="loading-layer" class="shadow-depth3"><i class="fa fa-spinner fa-spin"></i></div>
        <div class="navbar navbar-inverse">
            <div class="navbar-header">
                <a class="navbar-brand" href="?mod={$modLName}">{$dleSeoLang['name']} v1.2.1</a>
                <ul class="nav navbar-nav visible-xs-block">
                    <li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="fa fa-angle-double-down"></i></a></li>
                    <li><a class="sidebar-mobile-main-toggle"><i class="fa fa-bars"></i></a></li>
                </ul>
            </div>
            <div class="navbar-collapse collapse" id="navbar-mobile">
                <div class="navbar-right">	
                    <ul class="nav navbar-nav">
                        <li><a href="{$PHP_SELF}?mod={$modLName}" title="{$dleSeoLang['admin']['other']['main']}">{$dleSeoLang['admin']['other']['main']}</a></li>
                        <li><a href="{$PHP_SELF}" title="{$dleSeoLang['admin']['other']['all_menu_dle']}">{$dleSeoLang['admin']['other']['all_menu_dle']}</a></li>
                        <li><a href="{$config['http_home_url']}" title="{$dleSeoLang['admin']['other']['site']}" target="_blank">{$dleSeoLang['admin']['other']['site']}</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-container">
            <div class="page-content">
                
                <div class="content-wrapper">
                    <div class="page-header page-header-default">
                        <div class="breadcrumb-line">
                            <ul class="breadcrumb">
                                {$speedbar}
                            </ul>
HTML;
if (Data::get('cache', 'config')) {
    echo <<<HTML
							<input type="button" onclick="clearCache();" class="btn bg-danger btn-sm" style="float: right;border-radius: unset;font-size: 13px;margin-top: 4px;" value="{$dleSeoLang['admin']['clear_cache']}">
HTML;
$jsAdminScript[] = <<<HTML

let clearCache = function() {
	DLEconfirm("{$dleSeoLang['admin']['accept_cache']}", "{$dleSeoLang['admin']['try']}", function() {
		coreAdmin.ajaxSend(false, 'clearCache', false);
	});
	return false;
};

HTML;
}
echo <<<HTML
                        </div>
                    </div>
                    
                    <div class="content">
HTML;

?>