<?php
/**
* Настройки модуля
*
* @link https://lazydev.pro/
* @author LazyDev <email@lazydev.pro>
**/

use LazyDev\Seo\Admin;

$allXfield = xfieldsload();
foreach ($allXfield as $value) {
    $xfieldArray[$value[0]] = $value[1];
}

$indexArray = [
    'index' => $dleSeoLang['admin']['settings']['index'],
    'follow' => $dleSeoLang['admin']['settings']['follow'],
    'noindex' => $dleSeoLang['admin']['settings']['noindex']
];

echo <<<HTML
<form action="" method="post">
    <div class="panel panel-flat">
        <div class="table-responsive">
            <table class="table">
HTML;
Admin::row(
    $dleSeoLang['admin']['settings']['cache'],
    $dleSeoLang['admin']['settings']['cache_descr'],
    Admin::checkBox('cache', $dleSeoConfig['cache'], 'cache'),
    $dleSeoLang['admin']['settings']['cache_helper']
);
Admin::row(
    $dleSeoLang['admin']['settings']['xfield_alt'],
    $dleSeoLang['admin']['settings']['xfield_alt_descr'],
    Admin::checkBox('xfield_alt', $dleSeoConfig['xfield_alt'], 'xfield_alt')
);
Admin::row(
    $dleSeoLang['admin']['settings']['tags_alt'],
    $dleSeoLang['admin']['settings']['tags_alt_descr'],
    Admin::checkBox('tags_alt', $dleSeoConfig['tags_alt'], 'tags_alt')
);
echo <<<HTML
            </table>
        </div>
		<div class="panel-footer">
			<button type="submit" class="btn bg-teal btn-raised position-left" style="background-color:#1e8bc3;">{$dleSeoLang['admin']['save']}</button>
		</div>
    </div>
</form>
HTML;
$jsAdminScript[] = <<<HTML

$(function() {
    $('body').on('submit', 'form', function(e) {
        coreAdmin.ajaxSend($('form').serialize(), 'saveOptions', false);
		return false;
    });
});
function ChangeOption(obj, selectedOption) {
    $('#navbar-filter li').removeClass('active');
    $(obj).parent().addClass('active');
    $('[id*=block_]').hide();
    $('#' + selectedOption).show();

    return false;
}
HTML;

?>