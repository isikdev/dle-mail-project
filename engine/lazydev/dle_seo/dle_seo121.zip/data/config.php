<?php

//DLE Seo by LazyDev

return array (
  'cache' => 1,
);
