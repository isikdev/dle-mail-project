<?php
/**
 * Работа с подписками с сайта
 *
 * @link https://lazydev.pro/
 * @author LazyDev <email@lazydev.pro>
 **/

$hash = pathinfo($_SERVER['REQUEST_URI'], PATHINFO_BASENAME);
$hash = $db->safesql(trim(strip_tags(stripslashes($hash))));
use LazyDev\Subscribe\Data;

if (mb_strlen($hash, 'UTF-8') == 40) {
    $getSubscribe = $db->super_query("SELECT idSubscribe, confirmed FROM " . PREFIX . "_dle_subscribe WHERE hash='{$hash}'");
    if ($getSubscribe['idSubscribe'] > 0) {
        if (substr_count($_SERVER['REQUEST_URI'], 'accept')) {
            if ($getSubscribe['confirmed'] == 1) {
                msgbox(Data::get(['site', 'error'], 'lang'), Data::get(['site', 'errorAccept'], 'lang'));
            } else {
                $db->query("UPDATE " . PREFIX . "_dle_subscribe SET confirmed='1' WHERE hash='{$hash}'");
                msgbox(Data::get(['site', 'acceptEmail'], 'lang'), Data::get(['site', 'acceptEmailText'], 'lang'));
            }
        } elseif (substr_count($_SERVER['REQUEST_URI'], 'decline')) {
            $db->query("DELETE FROM " . PREFIX . "_dle_subscribe WHERE hash='{$hash}'");
            msgbox(Data::get(['site', 'declineEmail'], 'lang'), Data::get(['site', 'declineEmailText'], 'lang'));
        }
    } elseif (substr_count($_SERVER['REQUEST_URI'], 'decline') && !$getSubscribe['idSubscribe']) {
        msgbox(Data::get(['site', 'error'], 'lang'), Data::get(['site', 'errorDecline'], 'lang'));
    } else {
        msgbox(Data::get(['site', 'error'], 'lang'), Data::get(['site', 'errorData'], 'lang'));
    }
} else {
    msgbox(Data::get(['site', 'error'], 'lang'), Data::get(['site', 'errorData'], 'lang'));
}

$allow_active_news = false;