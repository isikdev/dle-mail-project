<?php

//DLE Subscribe by LazyDev

return array (
  'options' => 
  array (
    'guestApprove' => 1,
    'sendEmail' => 1,
    'dateUpdate' => 1,
  ),
);
