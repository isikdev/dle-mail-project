<?php
/**
 * Конфиг и языковый файл
 *
 * @link https://lazydev.pro/
 * @author LazyDev <email@lazydev.pro>
 **/

namespace LazyDev\Subscribe;

class Data
{
    static private $data = [];

    /**
     * Загрузить конфиг и языковый пакет
     */
    static function load()
    {
        self::$data['config'] = include_once realpath(__DIR__ . '/..')  . '/data/config.php';
        self::$data['lang'] = include_once realpath(__DIR__ . '/..')  . '/data/lang.lng';
    }

    /**
     * Вернуть массив данных
     *
     * @param   string  $key
     * @return  array
     */
    static function receive($key)
    {
        return self::$data[$key];
    }

    /**
     * Получить данные с массива по ключу
     *
     * @param    string|array   $key
     * @param    string         $type
     * @return   string
     */
    static public function get($key, $type)
    {
        if (is_array($key)) {
            return Helper::multiArray(self::$data[$type], $key, count($key));
        }

        return self::$data[$type][$key];
    }

}